# WordPress MySQL database migration
#
# Generated: Thursday 29. November 2018 14:56 UTC
# Hostname: localhost
# Database: `quotesondev`
# URL: //localhost/student
# Path: /Applications/MAMP/htdocs/student
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/student', 'yes'),
(2, 'home', 'http://localhost/student', 'yes'),
(3, 'blogname', 'Quotes on Dev', 'yes'),
(4, 'blogdescription', 'a site of quotes on dev', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'bachtuvien@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:89:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:23:"gutenberg/gutenberg.php";i:1;s:41:"wordpress-importer/wordpress-importer.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:3:{i:0;s:75:"/Applications/MAMP/htdocs/student/wp-content/themes/quotesondev/archive.php";i:1;s:73:"/Applications/MAMP/htdocs/student/wp-content/themes/quotesondev/style.css";i:2;s:0:"";}', 'no'),
(40, 'template', 'quotesondev', 'yes'),
(41, 'stylesheet', 'quotesondev', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'initial_db_version', '38590', 'yes'),
(93, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:73:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:11:"edit_blocks";b:1;s:18:"edit_others_blocks";b:1;s:14:"publish_blocks";b:1;s:19:"read_private_blocks";b:1;s:11:"read_blocks";b:1;s:13:"delete_blocks";b:1;s:21:"delete_private_blocks";b:1;s:23:"delete_published_blocks";b:1;s:20:"delete_others_blocks";b:1;s:19:"edit_private_blocks";b:1;s:21:"edit_published_blocks";b:1;s:13:"create_blocks";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:46:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:11:"edit_blocks";b:1;s:18:"edit_others_blocks";b:1;s:14:"publish_blocks";b:1;s:19:"read_private_blocks";b:1;s:11:"read_blocks";b:1;s:13:"delete_blocks";b:1;s:21:"delete_private_blocks";b:1;s:23:"delete_published_blocks";b:1;s:20:"delete_others_blocks";b:1;s:19:"edit_private_blocks";b:1;s:21:"edit_published_blocks";b:1;s:13:"create_blocks";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:17:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:11:"edit_blocks";b:1;s:14:"publish_blocks";b:1;s:11:"read_blocks";b:1;s:13:"delete_blocks";b:1;s:23:"delete_published_blocks";b:1;s:21:"edit_published_blocks";b:1;s:13:"create_blocks";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:11:"read_blocks";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(94, 'fresh_site', '0', 'yes'),
(95, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'cron', 'a:4:{i:1543506610;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1543520906;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1543520921;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(111, 'theme_mods_twentyseventeen', 'a:3:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1542920779;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(125, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:20:"bachtuvien@gmail.com";s:7:"version";s:5:"4.9.8";s:9:"timestamp";i:1542916118;}', 'no'),
(141, 'can_compress_scripts', '1', 'no'),
(144, 'recently_activated', 'a:0:{}', 'yes'),
(145, 'current_theme', 'Quotes on Dev Starter Theme', 'yes'),
(146, 'theme_mods_quotesondev-starter-master', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1542920776;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(147, 'theme_switched', '', 'yes'),
(154, 'category_children', 'a:0:{}', 'yes'),
(160, 'theme_mods_quotesondev', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(200, 'WPLANG', '', 'yes'),
(201, 'new_admin_email', 'bachtuvien@gmail.com', 'yes'),
(296, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1543503406;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(5, 19, '_edit_last', '2'),
(6, 21, '_edit_last', '2'),
(7, 21, '_qod_quote_source', 'The Structure and Interpretation of Computer Programs'),
(8, 23, '_edit_last', '2'),
(9, 25, '_edit_last', '2'),
(10, 27, '_edit_last', '2'),
(11, 29, '_edit_last', '2'),
(12, 31, '_edit_last', '2'),
(13, 33, '_edit_last', '2'),
(14, 33, '_qod_quote_source', 'Program or Be Programmed: Ten Commands for a Digital Age'),
(15, 35, '_edit_last', '2'),
(16, 37, '_edit_last', '2'),
(17, 37, '_qod_quote_source', 'Code Simplicity: The Fundamentals of Software'),
(18, 39, '_edit_last', '2'),
(19, 41, '_edit_last', '2'),
(20, 43, '_edit_last', '2'),
(21, 45, '_edit_last', '2'),
(22, 47, '_edit_last', '2'),
(23, 49, '_edit_last', '2'),
(24, 51, '_edit_last', '2'),
(25, 51, '_qod_quote_source', 'Game Programming Patterns'),
(26, 53, '_edit_last', '2'),
(27, 53, '_qod_quote_source', 'Game Programming Patterns'),
(28, 55, '_edit_last', '2'),
(29, 55, '_qod_quote_source', 'Clean Code: A Handbook of Agile Software Craftsmanship'),
(30, 57, '_edit_last', '2'),
(31, 57, '_qod_quote_source', 'Working Effectively with Legacy Code'),
(32, 59, '_edit_last', '2'),
(33, 61, '_edit_last', '2'),
(35, 63, '_edit_last', '2'),
(36, 65, '_edit_last', '2'),
(37, 67, '_edit_last', '2'),
(38, 69, '_edit_last', '2'),
(39, 71, '_edit_last', '2'),
(40, 73, '_edit_last', '2'),
(41, 75, '_edit_last', '2'),
(42, 77, '_edit_last', '2'),
(43, 79, '_edit_last', '2'),
(44, 79, '_qod_quote_source', 'The Mythical Man-Month'),
(45, 81, '_edit_last', '2'),
(46, 83, '_edit_last', '2'),
(47, 85, '_edit_last', '2'),
(48, 87, '_edit_last', '2'),
(49, 89, '_edit_last', '2'),
(50, 89, '_qod_quote_source', 'christianheilmann.com'),
(51, 89, '_qod_quote_source_url', 'https://www.christianheilmann.com/2005/11/08/do-hr-people-even-read-their-job-ads-when-they-get-published/'),
(52, 91, '_edit_last', '2'),
(53, 91, '_qod_quote_source', 'What Is Code?'),
(54, 91, '_qod_quote_source_url', 'http://www.bloomberg.com/graphics/2015-paul-ford-what-is-code/'),
(55, 93, '_edit_last', '2'),
(56, 95, '_edit_last', '2'),
(57, 97, '_edit_last', '2'),
(58, 101, '_edit_last', '2'),
(59, 101, '_qod_quote_source', 'The Art of Web Design'),
(60, 101, '_qod_quote_source_url', 'https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CDkQtwIwAGoVChMI1uS97rLuyAIVVfFjCh3DFwrM&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D3iVVM_DgWY4&usg=AFQjCNGKP6BAccnj6iPxgUB_UhEsW-A5xg'),
(61, 103, '_edit_last', '2'),
(62, 103, '_qod_quote_source', 'gerrymcgovern.com'),
(63, 103, '_qod_quote_source_url', 'http://www.gerrymcgovern.com/new-thinking/why-do-organizations-hate-their-content-management-system'),
(64, 105, '_edit_last', '2'),
(65, 105, '_qod_quote_source', 'Medium'),
(66, 105, '_qod_quote_source_url', 'https://medium.com/javascript-scene/the-two-pillars-of-javascript-ee6f3281e7f3'),
(67, 159, '_edit_last', '2'),
(68, 161, '_edit_last', '2'),
(69, 161, '_qod_quote_source', '@sanityinc'),
(70, 161, '_qod_quote_source_url', 'https://twitter.com/sanityinc'),
(71, 163, '_edit_last', '2'),
(72, 163, '_qod_quote_source', '@iamdevloper'),
(73, 163, '_qod_quote_source_url', 'https://twitter.com/iamdevloper'),
(74, 165, '_edit_last', '2'),
(75, 165, '_qod_quote_source', '@garybernhardt'),
(76, 165, '_qod_quote_source_url', 'https://twitter.com/garybernhardt'),
(77, 169, '_edit_last', '2'),
(78, 169, '_qod_quote_source', '@tomscott'),
(79, 169, '_qod_quote_source_url', 'https://twitter.com/tomscott'),
(80, 171, '_edit_last', '2'),
(81, 171, '_qod_quote_source', '@d6'),
(82, 171, '_qod_quote_source_url', 'https://twitter.com/d6'),
(83, 173, '_edit_last', '2'),
(84, 173, '_qod_quote_source', '@JaesCoyle'),
(85, 173, '_qod_quote_source_url', 'https://twitter.com/JaesCoyle'),
(86, 175, '_edit_last', '2'),
(87, 175, '_qod_quote_source', '@nedbat'),
(88, 175, '_qod_quote_source_url', 'https://twitter.com/nedbat'),
(89, 177, '_edit_last', '2'),
(90, 177, '_qod_quote_source', '@fortes'),
(91, 177, '_qod_quote_source_url', 'https://twitter.com/fortes'),
(92, 179, '_edit_last', '2'),
(93, 179, '_qod_quote_source', '@mhoye'),
(94, 179, '_qod_quote_source_url', 'https://twitter.com/mhoye'),
(95, 181, '_edit_last', '2'),
(96, 204, '_edit_last', '2'),
(97, 204, '_qod_quote_source', '@jamesshore'),
(98, 204, '_qod_quote_source_url', 'https://twitter.com/jamesshore'),
(99, 205, '_edit_lock', '1543261548:1'),
(100, 205, '_oembed_bf6964af303ed7ed4297755ba99a9f33', '<iframe src="https://player.vimeo.com/video/22439234?app_id=122963" width="640" height="360" frameborder="0" title="The Mountain" allow="autoplay; fullscreen" allowfullscreen></iframe>'),
(101, 205, '_oembed_time_bf6964af303ed7ed4297755ba99a9f33', '1543257092'),
(102, 206, '_edit_lock', '1543257023:1'),
(103, 207, '_edit_lock', '1543257988:1'),
(104, 204, '_edit_lock', '1543463678:1'),
(105, 179, '_edit_lock', '1543260250:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(106, 208, '_edit_lock', '1543268923:1'),
(108, 215, '_edit_lock', '1543269938:1'),
(115, 219, '_menu_item_type', 'custom'),
(116, 219, '_menu_item_menu_item_parent', '0'),
(117, 219, '_menu_item_object_id', '219'),
(118, 219, '_menu_item_object', 'custom'),
(119, 219, '_menu_item_target', ''),
(120, 219, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(121, 219, '_menu_item_xfn', ''),
(122, 219, '_menu_item_url', 'http://localhost/student/'),
(123, 219, '_menu_item_orphaned', '1543269382'),
(124, 220, '_menu_item_type', 'post_type'),
(125, 220, '_menu_item_menu_item_parent', '0'),
(126, 220, '_menu_item_object_id', '208'),
(127, 220, '_menu_item_object', 'page'),
(128, 220, '_menu_item_target', ''),
(129, 220, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(130, 220, '_menu_item_xfn', ''),
(131, 220, '_menu_item_url', ''),
(132, 220, '_menu_item_orphaned', '1543269382'),
(142, 222, '_menu_item_type', 'post_type'),
(143, 222, '_menu_item_menu_item_parent', '0'),
(144, 222, '_menu_item_object_id', '215'),
(145, 222, '_menu_item_object', 'page'),
(146, 222, '_menu_item_target', ''),
(147, 222, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(148, 222, '_menu_item_xfn', ''),
(149, 222, '_menu_item_url', ''),
(150, 222, '_menu_item_orphaned', '1543269382'),
(154, 223, '_edit_lock', '1543269486:1'),
(155, 224, '_edit_lock', '1543269645:1'),
(156, 225, '_edit_lock', '1543269718:1'),
(157, 226, '_edit_lock', '1543294933:1'),
(158, 226, '_edit_last', '1'),
(159, 226, '_wp_page_template', 'archive.php'),
(160, 1, '_wp_trash_meta_status', 'publish'),
(161, 1, '_wp_trash_meta_time', '1543332646'),
(162, 1, '_wp_desired_post_slug', 'hello-world'),
(163, 57, '_edit_lock', '1543341070:1'),
(164, 229, '_edit_lock', '1543341458:1'),
(167, 230, '_qod_quote_source', 'test 123'),
(168, 230, '_edit_lock', '1543464538:1'),
(170, 231, '_qod_quote_source', 'test'),
(173, 232, '_qod_quote_source', 'test'),
(176, 233, '_qod_quote_source', 'test'),
(179, 234, '_qod_quote_source', 'est'),
(180, 234, '_wp_desired_post_slug', 'test-5'),
(181, 233, '_wp_trash_meta_status', 'publish'),
(182, 233, '_wp_trash_meta_time', '1543465204'),
(183, 233, '_wp_desired_post_slug', 'test-4'),
(184, 232, '_wp_trash_meta_status', 'publish'),
(185, 232, '_wp_trash_meta_time', '1543465204'),
(186, 232, '_wp_desired_post_slug', 'test-3'),
(187, 231, '_wp_trash_meta_status', 'publish'),
(188, 231, '_wp_trash_meta_time', '1543465204'),
(189, 231, '_wp_desired_post_slug', 'test-2'),
(190, 230, '_wp_trash_meta_status', 'publish'),
(191, 230, '_wp_trash_meta_time', '1543465204'),
(192, 230, '_wp_desired_post_slug', 'test'),
(195, 241, '_qod_quote_source', 'test 123') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-11-22 19:48:26', '2018-11-22 19:48:26', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2018-11-27 15:30:46', '2018-11-27 15:30:46', '', 0, 'http://localhost/student/?p=1', 0, 'post', '', 1),
(4, 1, '2018-11-22 19:48:41', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-11-22 19:48:41', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=4', 0, 'post', '', 0),
(19, 2, '2015-10-30 23:13:59', '2015-10-30 23:13:59', '<!-- wp:paragraph -->\n<p>Talk is cheap. Show me the code.</p>\n<!-- /wp:paragraph -->', 'Linus Torvalds', '', 'publish', 'open', 'open', '', 'linus-torvalds', '', '', '2015-10-30 23:13:59', '2015-10-30 23:13:59', '', 0, 'http://localhost/quotesondev/?p=19', 0, 'post', '', 0),
(21, 2, '2015-10-30 23:35:43', '2015-10-30 23:35:43', '<!-- wp:paragraph -->\n<p>Programs must be written for people to read, and only incidentally for machines to execute.</p>\n<!-- /wp:paragraph -->', 'Harold Abelson', '', 'publish', 'open', 'open', '', 'harold-abelson', '', '', '2015-10-30 23:35:43', '2015-10-30 23:35:43', '', 0, 'http://localhost/quotesondev/?p=21', 0, 'post', '', 0),
(23, 2, '2015-10-30 23:36:35', '2015-10-30 23:36:35', '<!-- wp:paragraph -->\n<p>Always code as if the guy who ends up maintaining your code will be a violent psychopath who knows where you live.</p>\n<!-- /wp:paragraph -->', 'John Woods', '', 'publish', 'open', 'open', '', 'john-woods', '', '', '2015-10-30 23:36:35', '2015-10-30 23:36:35', '', 0, 'http://localhost/quotesondev/?p=23', 0, 'post', '', 0),
(25, 2, '2015-10-30 23:40:03', '2015-10-30 23:40:03', '<!-- wp:paragraph -->\n<p>Give a man a program, frustrate him for a day. Teach a man to program, frustrate him for a lifetime.</p>\n<!-- /wp:paragraph -->', 'Waseem Latif', '', 'publish', 'open', 'open', '', 'waseem-latif', '', '', '2015-10-30 23:40:03', '2015-10-30 23:40:03', '', 0, 'http://localhost/quotesondev/?p=25', 0, 'post', '', 0),
(27, 2, '2015-10-31 20:25:18', '2015-10-31 20:25:18', '<!-- wp:paragraph -->\n<p>Perl – The only language that looks the same before and after RSA encryption.</p>\n<!-- /wp:paragraph -->', 'Keith Bostic', '', 'publish', 'open', 'open', '', 'keith-bostic', '', '', '2015-10-31 20:25:18', '2015-10-31 20:25:18', '', 0, 'http://localhost/quotesondev/?p=27', 0, 'post', '', 0),
(29, 2, '2015-10-31 20:26:50', '2015-10-31 20:26:50', '<!-- wp:paragraph -->\n<p>Walking on water and developing software from a specification are easy if both are frozen.</p>\n<!-- /wp:paragraph -->', 'Edward Berard', '', 'publish', 'open', 'open', '', 'edward-berard', '', '', '2015-10-31 20:26:50', '2015-10-31 20:26:50', '', 0, 'http://localhost/quotesondev/?p=29', 0, 'post', '', 0),
(31, 2, '2015-10-31 20:27:03', '2015-10-31 20:27:03', '<!-- wp:paragraph -->\n<p>The most important property of a program is whether it accomplishes the intention of its user.</p>\n<!-- /wp:paragraph -->', 'C.A.R. Hoare', '', 'publish', 'open', 'open', '', 'c-a-r-hoare', '', '', '2015-10-31 20:27:03', '2015-10-31 20:27:03', '', 0, 'http://localhost/quotesondev/?p=31', 0, 'post', '', 0),
(33, 2, '2015-10-31 20:27:54', '2015-10-31 20:27:54', '<!-- wp:paragraph -->\n<p>We are looking at a society increasingly dependent on machines, yet decreasingly capable of making or even using them effectively.</p>\n<!-- /wp:paragraph -->', 'Douglas Rushkoff', '', 'publish', 'open', 'open', '', 'douglas-rushkoff', '', '', '2015-10-31 20:27:54', '2015-10-31 20:27:54', '', 0, 'http://localhost/quotesondev/?p=33', 0, 'post', '', 0),
(35, 2, '2015-10-31 20:28:34', '2015-10-31 20:28:34', '<!-- wp:paragraph -->\n<p>I\'m not a great programmer; I\'m just a good programmer with great habits.</p>\n<!-- /wp:paragraph -->', 'Kent Beck', '', 'publish', 'open', 'open', '', 'kent-beck', '', '', '2015-10-31 20:28:34', '2015-10-31 20:28:34', '', 0, 'http://localhost/quotesondev/?p=35', 0, 'post', '', 0),
(37, 2, '2015-10-31 20:29:52', '2015-10-31 20:29:52', '<!-- wp:paragraph -->\n<p>Some of the best programming is done on paper, really. Putting it into the computer is just a minor detail.</p>\n<!-- /wp:paragraph -->', 'Max Kanat-Alexander', '', 'publish', 'open', 'open', '', 'max-kanat-alexander', '', '', '2015-10-31 20:29:52', '2015-10-31 20:29:52', '', 0, 'http://localhost/quotesondev/?p=37', 0, 'post', '', 0),
(39, 2, '2015-10-31 20:30:38', '2015-10-31 20:30:38', '<!-- wp:paragraph -->\n<p>Any fool can write code that a computer can understand. Good programmers write code that humans can understand.</p>\n<!-- /wp:paragraph -->', 'Martin Fowler', '', 'publish', 'open', 'open', '', 'martin-fowler', '', '', '2015-10-31 20:30:38', '2015-10-31 20:30:38', '', 0, 'http://localhost/quotesondev/?p=39', 0, 'post', '', 0),
(41, 2, '2015-10-31 20:32:56', '2015-10-31 20:32:56', '<!-- wp:paragraph -->\n<p>Simplicity is prerequisite for reliability.</p>\n<!-- /wp:paragraph -->', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra', '', '', '2015-10-31 20:32:56', '2015-10-31 20:32:56', '', 0, 'http://localhost/quotesondev/?p=41', 0, 'post', '', 0),
(43, 2, '2015-10-31 20:33:49', '2015-10-31 20:33:49', '<!-- wp:paragraph -->\n<p>The Analytical Engine weaves algebraic patterns, just as the Jacquard loom weaves flowers and leaves.</p>\n<!-- /wp:paragraph -->', 'Ada Lovelace', '', 'publish', 'open', 'open', '', 'ada-lovelace', '', '', '2015-10-31 20:33:49', '2015-10-31 20:33:49', '', 0, 'http://localhost/quotesondev/?p=43', 0, 'post', '', 0),
(45, 2, '2015-10-31 20:34:48', '2015-10-31 20:34:48', '<!-- wp:paragraph -->\n<p>Sometimes it pays to stay in bed on Monday, rather than spending the rest of the week debugging Monday\'s code</p>\n<!-- /wp:paragraph -->', 'Dan Salomon', '', 'publish', 'open', 'open', '', 'dan-salomon', '', '', '2015-10-31 20:34:48', '2015-10-31 20:34:48', '', 0, 'http://localhost/quotesondev/?p=45', 0, 'post', '', 0),
(47, 2, '2015-10-31 20:35:52', '2015-10-31 20:35:52', '<!-- wp:paragraph -->\n<p>It goes against the grain of modern education to teach children to program. What fun is there in making plans, acquiring discipline in organizing thoughts, devoting attention to detail and learning to be self-critical?</p>\n<!-- /wp:paragraph -->', 'Alan J. Perlis', '', 'publish', 'open', 'open', '', 'alan-j-perlis', '', '', '2015-10-31 20:35:52', '2015-10-31 20:35:52', '', 0, 'http://localhost/quotesondev/?p=47', 0, 'post', '', 0),
(49, 2, '2015-10-31 20:36:12', '2015-10-31 20:36:12', '<!-- wp:paragraph -->\n<p>Kids who are good at traditional school—repeating rote concepts and facts on a test—can fall apart in a situation where that isn’t enough. Programming rewards the experimental, curious mind.</p>\n<!-- /wp:paragraph -->', 'Ketil Moland Olsen', '', 'publish', 'open', 'open', '', 'ketil-moland-olsen', '', '', '2015-10-31 20:36:12', '2015-10-31 20:36:12', '', 0, 'http://localhost/quotesondev/?p=49', 0, 'post', '', 0),
(51, 2, '2015-10-31 20:37:22', '2015-10-31 20:37:22', '<!-- wp:paragraph -->\n<p>Like so many things in software, MVC was invented by Smalltalkers in the seventies. Lispers probably claim they came up with it in the sixties but didn\'t bother writing it down.</p>\n<!-- /wp:paragraph -->', 'Robert Nystrom', '', 'publish', 'open', 'open', '', 'robert-nystrom', '', '', '2015-10-31 20:37:22', '2015-10-31 20:37:22', '', 0, 'http://localhost/quotesondev/?p=51', 0, 'post', '', 0),
(53, 2, '2015-10-31 20:38:02', '2015-10-31 20:38:02', '<!-- wp:paragraph -->\n<p>Most non-programmers don\'t think of plaintext like that. To them, text files feel like filling in tax forms for an angry robotic auditor that yells at them if they forget a single semicolon.</p>\n<!-- /wp:paragraph -->', 'Robert Nystrom', '', 'publish', 'open', 'open', '', 'robert-nystrom-2', '', '', '2015-10-31 20:38:02', '2015-10-31 20:38:02', '', 0, 'http://localhost/quotesondev/?p=53', 0, 'post', '', 0),
(55, 2, '2015-10-31 20:39:09', '2015-10-31 20:39:09', '<!-- wp:paragraph -->\n<p>Truth can only be found in one place: the code.</p>\n<!-- /wp:paragraph -->', 'Robert C. Martin', '', 'publish', 'open', 'open', '', 'robert-c-martin', '', '', '2015-10-31 20:39:09', '2015-10-31 20:39:09', '', 0, 'http://localhost/quotesondev/?p=55', 0, 'post', '', 0),
(57, 2, '2015-10-31 20:39:46', '2015-10-31 20:39:46', '<!-- wp:paragraph -->\n<p>Programming is the art of doing one thing at a time.</p>\n<!-- /wp:paragraph -->', 'Michael C. Feathers', '', 'publish', 'open', 'open', '', 'michael-c-feathers', '', '', '2015-10-31 20:39:46', '2015-10-31 20:39:46', '', 0, 'http://localhost/quotesondev/?p=57', 0, 'post', '', 0),
(59, 2, '2015-10-31 20:57:19', '2015-10-31 20:57:19', '<!-- wp:paragraph -->\n<p>I love deadlines. I like the whooshing sound they make as they go by.</p>\n<!-- /wp:paragraph -->', 'Douglas Adams', '', 'publish', 'open', 'open', '', 'douglas-adams', '', '', '2015-10-31 20:57:19', '2015-10-31 20:57:19', '', 0, 'http://localhost/quotesondev/?p=59', 0, 'post', '', 0),
(61, 2, '2015-10-31 20:57:57', '2015-10-31 20:57:57', '<!-- wp:paragraph -->\n<p>If debugging is the process of removing software bugs, then programming must be the process of putting them in.</p>\n<!-- /wp:paragraph -->', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra-2', '', '', '2015-10-31 20:57:57', '2015-10-31 20:57:57', '', 0, 'http://localhost/quotesondev/?p=61', 0, 'post', '', 0),
(63, 2, '2015-10-31 20:58:40', '2015-10-31 20:58:40', '<!-- wp:paragraph -->\n<p>There are two ways of constructing a software design: One way is to make it so simple that there are obviously no deficiencies, and the other way is to make it so complicated that there are no obvious deficiencies. The first method is far more difficult.</p>\n<!-- /wp:paragraph -->', 'C.A.R. Hoare', '', 'publish', 'open', 'open', '', 'c-a-r-hoare-2', '', '', '2015-10-31 20:58:40', '2015-10-31 20:58:40', '', 0, 'http://localhost/quotesondev/?p=63', 0, 'post', '', 0),
(65, 2, '2015-10-31 20:59:24', '2015-10-31 20:59:24', '<!-- wp:paragraph -->\n<p>Measuring programming progress by lines of code is like measuring aircraft building progress by weight.</p>\n<!-- /wp:paragraph -->', 'Bill Gates', '', 'publish', 'open', 'open', '', 'bill-gates', '', '', '2015-10-31 20:59:24', '2015-10-31 20:59:24', '', 0, 'http://localhost/quotesondev/?p=65', 0, 'post', '', 0),
(67, 2, '2015-10-31 21:00:01', '2015-10-31 21:00:01', '<!-- wp:paragraph -->\n<p>Most good programmers do programming not because they expect to get paid or get adulation by the public, but because it is fun to program.</p>\n<!-- /wp:paragraph -->', 'Linus Torvalds', '', 'publish', 'open', 'open', '', 'linus-torvalds-2', '', '', '2015-10-31 21:00:01', '2015-10-31 21:00:01', '', 0, 'http://localhost/quotesondev/?p=67', 0, 'post', '', 0),
(69, 2, '2015-10-31 21:00:54', '2015-10-31 21:00:54', '<!-- wp:paragraph -->\n<p>People think that computer science is the art of geniuses but the actual reality is the opposite, just many people doing things that build on each other, like a wall of mini stones.</p>\n<!-- /wp:paragraph -->', 'Donald Knuth', '', 'publish', 'open', 'open', '', 'donald-knuth', '', '', '2015-10-31 21:00:54', '2015-10-31 21:00:54', '', 0, 'http://localhost/quotesondev/?p=69', 0, 'post', '', 0),
(71, 2, '2015-10-31 21:01:52', '2015-10-31 21:01:52', '<!-- wp:paragraph -->\n<p>One of my most productive days was throwing away 1000 lines of code.</p>\n<!-- /wp:paragraph -->', 'Ken Thompson', '', 'publish', 'open', 'open', '', 'ken-thompson', '', '', '2015-10-31 21:01:52', '2015-10-31 21:01:52', '', 0, 'http://localhost/quotesondev/?p=71', 0, 'post', '', 0),
(73, 2, '2015-10-31 21:02:24', '2015-10-31 21:02:24', '<!-- wp:paragraph -->\n<p>If builders built buildings the way programmers wrote programs, then the first woodpecker that came along wound destroy civilization.</p>\n<!-- /wp:paragraph -->', 'Gerald Weinberg', '', 'publish', 'open', 'open', '', 'gerald-weinberg', '', '', '2015-10-31 21:02:24', '2015-10-31 21:02:24', '', 0, 'http://localhost/quotesondev/?p=73', 0, 'post', '', 0),
(75, 2, '2015-10-31 21:03:04', '2015-10-31 21:03:04', '<!-- wp:paragraph -->\n<p>Debugging is twice as hard as writing the code in the first place. Therefore, if you write the code as cleverly as possible, you are, by definition, not smart enough to debug it.</p>\n<!-- /wp:paragraph -->', 'Brian W. Kernighan', '', 'publish', 'open', 'open', '', 'brian-w-kernighan', '', '', '2015-10-31 21:03:04', '2015-10-31 21:03:04', '', 0, 'http://localhost/quotesondev/?p=75', 0, 'post', '', 0),
(77, 2, '2015-10-31 21:03:48', '2015-10-31 21:03:48', '<!-- wp:paragraph -->\n<p>Some people, when confronted with a problem, think "I know, I\'ll use regular expressions." Now they have two problems.</p>\n<!-- /wp:paragraph -->', 'Jamie Zawinski', '', 'publish', 'open', 'open', '', 'jamie-zawinski', '', '', '2015-10-31 21:03:48', '2015-10-31 21:03:48', '', 0, 'http://localhost/quotesondev/?p=77', 0, 'post', '', 0),
(79, 2, '2015-10-31 21:04:45', '2015-10-31 21:04:45', '<!-- wp:paragraph -->\n<p>Nine people can\'t make a baby in a month.</p>\n<!-- /wp:paragraph -->', 'Fred Brooks', '', 'publish', 'open', 'open', '', 'fred-brooks', '', '', '2015-10-31 21:04:45', '2015-10-31 21:04:45', '', 0, 'http://localhost/quotesondev/?p=79', 0, 'post', '', 0),
(81, 2, '2015-10-31 21:05:37', '2015-10-31 21:05:37', '<!-- wp:paragraph -->\n<p>Computer Science is no more about computers than astronomy is about telescopes.</p>\n<!-- /wp:paragraph -->', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra-3', '', '', '2015-10-31 21:05:37', '2015-10-31 21:05:37', '', 0, 'http://localhost/quotesondev/?p=81', 0, 'post', '', 0),
(83, 2, '2015-10-31 21:06:01', '2015-10-31 21:06:01', '<!-- wp:paragraph -->\n<p>There are only two kinds of languages: the ones people complain about and the ones nobody uses.</p>\n<!-- /wp:paragraph -->', 'Bjarne Stroustrup', '', 'publish', 'open', 'open', '', 'bjarne-stroustrup', '', '', '2015-10-31 21:06:01', '2015-10-31 21:06:01', '', 0, 'http://localhost/quotesondev/?p=83', 0, 'post', '', 0),
(85, 2, '2015-10-31 21:06:22', '2015-10-31 21:06:22', '<!-- wp:paragraph -->\n<p>The best thing about a boolean is even if you are wrong, you are only off by a bit.</p>\n<!-- /wp:paragraph -->', 'Anonymous', '', 'publish', 'open', 'open', '', 'anonymous', '', '', '2015-10-31 21:06:22', '2015-10-31 21:06:22', '', 0, 'http://localhost/quotesondev/?p=85', 0, 'post', '', 0),
(87, 2, '2015-10-31 21:07:06', '2015-10-31 21:07:06', '<!-- wp:paragraph -->\n<p>Commenting your code is like cleaning your bathroom—you never want to do it, but it really does create a more pleasant experience for you and your guests.</p>\n<!-- /wp:paragraph -->', 'Ryan Campbell', '', 'publish', 'open', 'open', '', 'ryan-campbell', '', '', '2015-10-31 21:07:06', '2015-10-31 21:07:06', '', 0, 'http://localhost/quotesondev/?p=87', 0, 'post', '', 0),
(89, 2, '2015-10-31 21:07:37', '2015-10-31 21:07:37', '<!-- wp:paragraph -->\n<p>Java is to JavaScript as car is to carpet.</p>\n<!-- /wp:paragraph -->', 'Chris Heilmann', '', 'publish', 'open', 'open', '', 'chris-heilmann', '', '', '2015-10-31 21:07:37', '2015-10-31 21:07:37', '', 0, 'http://localhost/quotesondev/?p=89', 0, 'post', '', 0),
(91, 2, '2015-10-31 21:10:27', '2015-10-31 21:10:27', '<!-- wp:paragraph -->\n<p>A computer is a clock with benefits.</p>\n<!-- /wp:paragraph -->', 'Paul Ford', '', 'publish', 'open', 'open', '', 'paul-ford', '', '', '2015-10-31 21:10:27', '2015-10-31 21:10:27', '', 0, 'http://localhost/quotesondev/?p=91', 0, 'post', '', 0),
(93, 2, '2015-10-31 21:11:54', '2015-10-31 21:11:54', '<!-- wp:paragraph -->\n<p>Programming is not a zero-sum game. Teaching something to a fellow programmer doesn\'t take it away from you. I\'m happy to share what I can, because I\'m in it for the love of programming.</p>\n<!-- /wp:paragraph -->', 'John Carmack', '', 'publish', 'open', 'open', '', 'john-carmack', '', '', '2015-10-31 21:11:54', '2015-10-31 21:11:54', '', 0, 'http://localhost/quotesondev/?p=93', 0, 'post', '', 0),
(95, 2, '2015-10-31 21:13:05', '2015-10-31 21:13:05', '<!-- wp:paragraph -->\n<p>You might not think that programmers are artists, but programming is an extremely creative profession. It\'s logic-based creativity.</p>\n<!-- /wp:paragraph -->', 'John Romero', '', 'publish', 'open', 'open', '', 'john-romero', '', '', '2015-10-31 21:13:05', '2015-10-31 21:13:05', '', 0, 'http://localhost/quotesondev/?p=95', 0, 'post', '', 0),
(97, 2, '2015-10-31 21:14:21', '2015-10-31 21:14:21', '<!-- wp:paragraph -->\n<p>There are two ways to write error-free programs; only the third one works.</p>\n<!-- /wp:paragraph -->', 'Alan J. Perlis', '', 'publish', 'open', 'open', '', 'alan-j-perlis-2', '', '', '2015-10-31 21:14:21', '2015-10-31 21:14:21', '', 0, 'http://localhost/quotesondev/?p=97', 0, 'post', '', 0),
(101, 2, '2015-11-01 04:35:03', '2015-11-01 04:35:03', '<!-- wp:paragraph -->\n<p>HTML is the cockroach that will survive a nuclear winter.</p>\n<!-- /wp:paragraph -->', 'Jeffery Zeldman', '', 'publish', 'open', 'open', '', 'jeffery-zeldman', '', '', '2015-11-01 04:35:03', '2015-11-01 04:35:03', '', 0, 'http://localhost/quotesondev/?p=101', 0, 'post', '', 0),
(103, 2, '2015-11-01 04:35:57', '2015-11-01 04:35:57', '<!-- wp:paragraph -->\n<p>A typical CMS is like a digestive system with no capacity to poop.</p>\n<!-- /wp:paragraph -->', 'Gerry McGovern', '', 'publish', 'open', 'open', '', 'gerry-mcgovern', '', '', '2015-11-01 04:35:57', '2015-11-01 04:35:57', '', 0, 'http://localhost/quotesondev/?p=103', 0, 'post', '', 0),
(105, 2, '2015-11-01 04:40:12', '2015-11-01 04:40:12', '<!-- wp:paragraph -->\n<p>What you make with your code is how you express yourself.</p>\n<!-- /wp:paragraph -->', 'Eric Elliott', '', 'publish', 'open', 'open', '', 'eric-elliott', '', '', '2015-11-01 04:40:12', '2015-11-01 04:40:12', '', 0, 'http://localhost/quotesondev/?p=105', 0, 'post', '', 0),
(159, 2, '2017-10-10 21:41:55', '2017-10-10 21:41:55', '<!-- wp:paragraph -->\n<p>Hardware eventually fails. Software eventually works.</p>\n<!-- /wp:paragraph -->', 'Michael Hartung', '', 'publish', 'open', 'open', '', 'michael-hartung', '', '', '2017-10-10 21:41:55', '2017-10-10 21:41:55', '', 0, 'http://localhost/quotesondev/?p=159', 0, 'post', '', 0),
(161, 2, '2017-10-10 21:44:10', '2017-10-10 21:44:10', '<!-- wp:paragraph -->\n<p>The Release Uncertainty Principle says you can accurately know what the software will do, or when you will get it, but not both.</p>\n<!-- /wp:paragraph -->', 'Steve Purcell', '', 'publish', 'open', 'open', '', 'steve-purcell', '', '', '2017-10-10 21:44:10', '2017-10-10 21:44:10', '', 0, 'http://localhost/quotesondev/?p=161', 0, 'post', '', 0),
(163, 2, '2017-10-10 21:45:46', '2017-10-10 21:45:46', '<!-- wp:paragraph -->\n<p>The barman asks what the first one wants, two race conditions walk into a bar.</p>\n<!-- /wp:paragraph -->', 'I Am Devloper', '', 'publish', 'open', 'open', '', 'i-am-devloper', '', '', '2017-10-10 21:45:46', '2017-10-10 21:45:46', '', 0, 'http://localhost/quotesondev/?p=163', 0, 'post', '', 0),
(165, 2, '2017-10-10 21:47:46', '2017-10-10 21:47:46', '<!-- wp:paragraph -->\n<p>Programmer’s motto: “We’ll cross that bridge when it’s burning underneath us.”</p>\n<!-- /wp:paragraph -->', 'Gary Bernhardt', '', 'publish', 'open', 'open', '', 'gary-bernhardt', '', '', '2017-10-10 21:47:46', '2017-10-10 21:47:46', '', 0, 'http://localhost/quotesondev/?p=165', 0, 'post', '', 0),
(169, 2, '2017-10-11 12:56:06', '2017-10-11 12:56:06', '<!-- wp:paragraph -->\n<p>Some programmers, when confronted with a problem, think “I know, I’ll use floating point arithmetic.” Now they have 1.999999999997 problems.</p>\n<!-- /wp:paragraph -->', 'Tom Scott', '', 'publish', 'open', 'open', '', 'tom-scott', '', '', '2017-10-11 12:56:06', '2017-10-11 12:56:06', '', 0, 'http://localhost/quotesondev/?p=169', 0, 'post', '', 0),
(171, 2, '2017-10-11 12:57:15', '2017-10-11 12:57:15', '<!-- wp:paragraph -->\n<p>Some people, when confronted with a problem, think “I know, I’ll use multithreading”. Nothhw tpe yawrve o oblems.</p>\n<!-- /wp:paragraph -->', 'Erik Osheim', '', 'publish', 'open', 'open', '', 'erik-osheim', '', '', '2017-10-11 12:57:15', '2017-10-11 12:57:15', '', 0, 'http://localhost/quotesondev/?p=171', 0, 'post', '', 0),
(173, 2, '2017-10-11 12:58:13', '2017-10-11 12:58:13', '<!-- wp:paragraph -->\n<p>Some people, when confronted with a problem, think “I know, I’ll use versioning.” Now they have 2.1.0 problems.</p>\n<!-- /wp:paragraph -->', 'Jason Coyle', '', 'publish', 'open', 'open', '', 'jason-coyle', '', '', '2017-10-11 12:58:13', '2017-10-11 12:58:13', '', 0, 'http://localhost/quotesondev/?p=173', 0, 'post', '', 0),
(175, 2, '2017-10-11 12:58:58', '2017-10-11 12:58:58', '<!-- wp:paragraph -->\n<p>Some people, when faced with a problem, think, “I know, I’ll use binary.” Now they have 10 problems.</p>\n<!-- /wp:paragraph -->', 'Ned Batchelder', '', 'publish', 'open', 'open', '', 'ned-batchelder', '', '', '2017-10-11 12:58:58', '2017-10-11 12:58:58', '', 0, 'http://localhost/quotesondev/?p=175', 0, 'post', '', 0),
(177, 2, '2017-10-11 13:06:37', '2017-10-11 13:06:37', '<!-- wp:paragraph -->\n<p>Debugging is like being the detective in a crime movie where you are also the murderer.</p>\n<!-- /wp:paragraph -->', 'Filipe Fortes', '', 'publish', 'open', 'open', '', 'filipe-fortes', '', '', '2017-10-11 13:06:37', '2017-10-11 13:06:37', '', 0, 'http://localhost/quotesondev/?p=177', 0, 'post', '', 0),
(179, 2, '2017-10-11 13:26:04', '2017-10-11 13:26:04', '<!-- wp:paragraph -->\n<p>Unix will give you enough rope to shoot yourself in the foot. If you didn’t think rope would do that, you should have read the man page.</p>\n<!-- /wp:paragraph -->', 'Mike Hoye', '', 'publish', 'open', 'open', '', 'mike-hoye', '', '', '2017-10-11 13:26:04', '2017-10-11 13:26:04', '', 0, 'http://localhost/quotesondev/?p=179', 0, 'post', '', 0),
(181, 2, '2017-10-11 13:27:11', '2017-10-11 13:27:11', '<!-- wp:paragraph -->\n<p>When your hammer is C++, everything begins to look like a thumb.</p>\n<!-- /wp:paragraph -->', 'Steve Haflich', '', 'publish', 'open', 'open', '', 'steve-haflich', '', '', '2017-10-11 13:27:11', '2017-10-11 13:27:11', '', 0, 'http://localhost/quotesondev/?p=181', 0, 'post', '', 0),
(204, 2, '2017-10-11 13:45:57', '2017-10-11 13:45:57', '<!-- wp:paragraph -->\n<p>Do; or do not. There is no //TODO</p>\n<!-- /wp:paragraph -->', 'James Shore', '', 'publish', 'open', 'open', '', 'james-shore', '', '', '2017-10-11 13:45:57', '2017-10-11 13:45:57', '', 0, 'http://localhost/quotesondev/?p=204', 0, 'post', '', 0),
(205, 1, '2018-11-26 18:32:16', '0000-00-00 00:00:00', '<!-- wp:cover {"url":"https://cldup.com/Fz-ASbo2s3.jpg","align":"wide"} -->\n<div class="wp-block-cover has-background-dim alignwide" style="background-image:url(https://cldup.com/Fz-ASbo2s3.jpg)"><p class="wp-block-cover-text">Of Mountains &amp; Printing Presses</p></div>\n<!-- /wp:cover -->\n\n<!-- wp:paragraph -->\n<p>The goal of this new editor is to make adding rich content to WordPress simple and enjoyable. This whole post is composed of <em>pieces of content</em>—somewhat similar to LEGO bricks—that you can move around and interact with. Move your cursor around and you’ll notice the different blocks light up with outlines and arrows. Press the arrows to reposition blocks quickly, without fearing about losing things in the process of copying and pasting.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>What you are reading now is a <strong>text block</strong> the most basic block of all. The text block has its own controls to be moved freely around the post...</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"right"} -->\n<p style="text-align:right">... like this one, which is right aligned.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Headings are separate blocks as well, which helps with the outline and organization of your content.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>A Picture is Worth a Thousand Words</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Handling images and media with the utmost care is a primary focus of the new editor. Hopefully, you’ll find aspects of adding captions or going full-width with your pictures much easier and robust than before.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class="wp-block-image"><img alt=""/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Try selecting and removing or editing the caption, now you don’t have to be careful about selecting the image or other text by mistake and ruining the presentation.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>The <em>Inserter</em> Tool</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Imagine everything that WordPress can do is available to you quickly and in the same place on the interface. No need to figure out HTML tags, classes, or remember complicated shortcode syntax. That’s the spirit behind the inserter—the <code>(+)</code> button you’ll see around the editor—which allows you to browse all available content blocks and add them into your post. Plugins and themes are able to register their own, opening up all sort of possibilities for rich editing and publishing.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Go give it a try, you may discover things WordPress can already add into your posts that you didn’t know about. Here’s a short list of what you can currently find there:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>Text &amp; Headings</li><li>Images &amp; Videos</li><li>Galleries</li><li>Embeds, like YouTube, Tweets, or other WordPress posts.</li><li>Layout blocks, like Buttons, Hero Images, Separators, etc.</li><li>And <em>Lists</em> like this one of course :)</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator"/>\n<!-- /wp:separator -->\n\n<!-- wp:heading -->\n<h2>Visual Editing</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>A huge benefit of blocks is that you can edit them in place and manipulate your content directly. Instead of having fields for editing things like the source of a quote, or the text of a button, you can directly change the content. Try editing the following quote:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The editor will endeavor to create a new page and post building experience that makes writing rich posts effortless, and has “blocks” to make it easy what today might take shortcodes, custom HTML, or “mystery meat” embed discovery.</p><cite>Matt Mullenweg, 2017</cite></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>The information corresponding to the source of the quote is a separate text field, similar to captions under images, so the structure of the quote is protected even if you select, modify, or remove the source. It’s always easy to add it back.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Blocks can be anything you need. For instance, you may want to add a subdued quote as part of the composition of your text, or you may prefer to display a giant stylized one. All of these options are available in the inserter.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {"ids":[null,null,null],"columns":2} -->\n<ul class="wp-block-gallery columns-2 is-cropped"><li class="blocks-gallery-item"><figure><img src="https://cldup.com/n0g6ME5VKC.jpg" alt=""/></figure></li><li class="blocks-gallery-item"><figure><img src="https://cldup.com/ZjESfxPI3R.jpg" alt=""/></figure></li><li class="blocks-gallery-item"><figure><img src="https://cldup.com/EKNF8xD2UM.jpg" alt=""/></figure></li></ul>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p>You can change the amount of columns in your galleries by dragging a slider in the block inspector in the sidebar.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2>Media Rich</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>If you combine the new <strong>wide</strong> and <strong>full-wide</strong> alignments with galleries, you can create a very media rich layout, very quickly:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"align":"full"} -->\n<figure class="wp-block-image alignfull"><img src="https://cldup.com/8lhI-gKnI2.jpg" alt="Accessibility is important — don’t forget image alt attribute"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>Sure, the full-wide image can be pretty big. But sometimes the image is worth it.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:gallery {"ids":[null,null],"align":"wide","className":"alignwide"} -->\n<ul class="wp-block-gallery alignwide columns-2 is-cropped"><li class="blocks-gallery-item"><figure><img src="https://cldup.com/_rSwtEeDGD.jpg" alt=""/></figure></li><li class="blocks-gallery-item"><figure><img src="https://cldup.com/L-cC3qX2DN.jpg" alt=""/></figure></li></ul>\n<!-- /wp:gallery -->\n\n<!-- wp:paragraph -->\n<p>The above is a gallery with just two images. It’s an easier way to create visually appealing layouts, without having to deal with floats. You can also easily convert the gallery back to individual images again, by using the block switcher.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Any block can opt into these alignments. The embed block has them also, and is responsive out of the box:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:core-embed/vimeo {"url":"https://vimeo.com/22439234","type":"video","providerNameSlug":"vimeo","align":"wide","className":"wp-has-aspect-ratio wp-embed-aspect-16-9"} -->\n<figure class="wp-block-embed-vimeo alignwide wp-block-embed is-type-video is-provider-vimeo wp-has-aspect-ratio wp-embed-aspect-16-9"><div class="wp-block-embed__wrapper">\nhttps://vimeo.com/22439234\n</div></figure>\n<!-- /wp:core-embed/vimeo -->\n\n<!-- wp:paragraph -->\n<p>You can build any block you like, static or dynamic, decorative or plain. Here’s a pullquote block:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:pullquote -->\n<figure class="wp-block-pullquote"><blockquote><p>Code is Poetry</p><cite>The WordPress community</cite></blockquote></figure>\n<!-- /wp:pullquote -->\n\n<!-- wp:paragraph {"align":"center"} -->\n<p style="text-align:center">\n	<em>\n		If you want to learn more about how to build additional blocks, or if you are interested in helping with the project, head over to the <a href="https://github.com/WordPress/gutenberg">GitHub repository</a>.	</em>\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:button {"align":"center"} -->\n<div class="wp-block-button aligncenter"><a class="wp-block-button__link" href="https://github.com/WordPress/gutenberg">Help build Gutenberg</a></div>\n<!-- /wp:button -->\n\n<!-- wp:separator -->\n<hr class="wp-block-separator"/>\n<!-- /wp:separator -->\n\n<!-- wp:paragraph {"align":"center"} -->\n<p style="text-align:center">Thanks for testing Gutenberg!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {"align":"center"} -->\n<p style="text-align:center"><img draggable="false" class="emoji" alt="👋" src="https://s.w.org/images/core/emoji/2.3/svg/1f44b.svg"></p>\n<!-- /wp:paragraph -->', 'Welcome to the Gutenberg Editor', '', 'draft', 'closed', 'open', '', '', '', '', '2018-11-26 18:32:16', '2018-11-26 18:32:16', '', 0, 'http://localhost/student/?p=205', 0, 'post', '', 0),
(206, 1, '2018-11-26 18:32:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2018-11-26 18:32:26', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=206', 0, 'post', '', 0),
(207, 1, '2018-11-26 18:32:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2018-11-26 18:32:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=207', 0, 'post', '', 0),
(208, 1, '2018-11-26 19:34:59', '2018-11-26 19:34:59', '<!-- wp:html -->\n<p>Quotes on Dev is a project site for the RED Academy Web Developer Professional program. It’s used to experiment with Ajax, WP API, jQuery, and other cool things.&nbsp; <img draggable="false" class="emoji" alt=":-)" src="https://s.w.org/images/core/emoji/11/svg/1f642.svg"</p>\n<!-- /wp:html -->\n\n<!-- wp:paragraph -->\n<p>This site&nbsp;is heavily inspired by Chris Coyier’s&nbsp;<a href="http://quotesondesign.com/" target="_blank" rel="noreferrer noopener">Quotes on Design</a>.</p>\n<!-- /wp:paragraph -->', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-11-26 19:43:30', '2018-11-26 19:43:30', '', 0, 'http://localhost/student/?page_id=208', 0, 'page', '', 0),
(209, 1, '2018-11-26 19:34:59', '2018-11-26 19:34:59', '<!-- wp:paragraph -->\n<p>Quotes on Dev is a project site for the RED Academy Web Developer Professional program. It’s used to experiment with Ajax, WP API, jQuery, and other cool things.&nbsp;</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"width":20,"height":20} -->\n<figure class="wp-block-image is-resized"><img src="https://s.w.org/images/core/emoji/11/svg/1f642.svg" alt="🙂" width="20" height="20"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>This site&nbsp;is heavily inspired by Chris Coyier’s&nbsp;<a href="http://quotesondesign.com/" target="_blank" rel="noreferrer noopener">Quotes on Design</a>.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2018-11-26 19:34:59', '2018-11-26 19:34:59', '', 208, 'http://localhost/student/2018/11/26/208-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2018-11-26 19:41:49', '2018-11-26 19:41:49', '<!-- wp:image {"width":20,"height":20} -->\n<figure class="wp-block-image is-resized"><img src="https://s.w.org/images/core/emoji/11/svg/1f642.svg" alt="🙂" width="20" height="20"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:html -->\n<p>Quotes on Dev is a project site for the RED Academy Web Developer Professional program. It’s used to experiment with Ajax, WP API, jQuery, and other cool things.&nbsp; <img draggable="false" class="emoji" alt=":-)" src="https://s.w.org/images/core/emoji/11/svg/1f642.svg"</p> \n<!-- /wp:html -->\n\n<!-- wp:paragraph -->\n<p>This site&nbsp;is heavily inspired by Chris Coyier’s&nbsp;<a href="http://quotesondesign.com/" target="_blank" rel="noreferrer noopener">Quotes on Design</a>.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2018-11-26 19:41:49', '2018-11-26 19:41:49', '', 208, 'http://localhost/student/2018/11/26/208-revision-v1/', 0, 'revision', '', 0),
(212, 1, '2018-11-26 19:43:30', '2018-11-26 19:43:30', '<!-- wp:html -->\n<p>Quotes on Dev is a project site for the RED Academy Web Developer Professional program. It’s used to experiment with Ajax, WP API, jQuery, and other cool things.&nbsp; <img draggable="false" class="emoji" alt=":-)" src="https://s.w.org/images/core/emoji/11/svg/1f642.svg"</p>\n<!-- /wp:html -->\n\n<!-- wp:paragraph -->\n<p>This site&nbsp;is heavily inspired by Chris Coyier’s&nbsp;<a href="http://quotesondesign.com/" target="_blank" rel="noreferrer noopener">Quotes on Design</a>.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2018-11-26 19:43:30', '2018-11-26 19:43:30', '', 208, 'http://localhost/student/2018/11/26/208-revision-v1/', 0, 'revision', '', 0),
(215, 1, '2018-11-26 20:21:04', '2018-11-26 20:21:04', '', 'Submit', '', 'publish', 'closed', 'closed', '', 'submit', '', '', '2018-11-26 20:21:04', '2018-11-26 20:21:04', '', 0, 'http://localhost/student/?page_id=215', 0, 'page', '', 0),
(216, 1, '2018-11-26 20:21:04', '2018-11-26 20:21:04', '', 'Submit', '', 'inherit', 'closed', 'closed', '', '215-revision-v1', '', '', '2018-11-26 20:21:04', '2018-11-26 20:21:04', '', 215, 'http://localhost/student/2018/11/26/215-revision-v1/', 0, 'revision', '', 0),
(219, 1, '2018-11-26 21:56:22', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-11-26 21:56:22', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=219', 1, 'nav_menu_item', '', 0),
(220, 1, '2018-11-26 21:56:22', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-11-26 21:56:22', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=220', 1, 'nav_menu_item', '', 0),
(222, 1, '2018-11-26 21:56:22', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-11-26 21:56:22', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=222', 1, 'nav_menu_item', '', 0),
(223, 1, '2018-11-26 22:00:14', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-11-26 22:00:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=223', 0, 'page', '', 0),
(224, 1, '2018-11-26 22:01:34', '0000-00-00 00:00:00', '<!-- wp:latest-posts /-->', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-11-26 22:01:34', '2018-11-26 22:01:34', '', 0, 'http://localhost/student/?page_id=224', 0, 'page', '', 0),
(225, 1, '2018-11-26 22:04:09', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-11-26 22:04:09', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=225', 0, 'page', '', 0),
(226, 1, '2018-11-27 03:49:48', '2018-11-27 03:49:48', '', 'Archives', '', 'publish', 'closed', 'closed', '', 'archives', '', '', '2018-11-27 04:02:16', '2018-11-27 04:02:16', '', 0, 'http://localhost/student/?page_id=226', 0, 'page', '', 0),
(227, 1, '2018-11-27 03:49:48', '2018-11-27 03:49:48', '', 'Archives', '', 'inherit', 'closed', 'closed', '', '226-revision-v1', '', '', '2018-11-27 03:49:48', '2018-11-27 03:49:48', '', 226, 'http://localhost/student/2018/11/27/226-revision-v1/', 0, 'revision', '', 0),
(228, 1, '2018-11-27 15:30:46', '2018-11-27 15:30:46', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-11-27 15:30:46', '2018-11-27 15:30:46', '', 1, 'http://localhost/student/2018/11/27/1-revision-v1/', 0, 'revision', '', 0),
(229, 1, '2018-11-27 17:53:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2018-11-27 17:53:34', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=229', 0, 'post', '', 0),
(230, 1, '2018-11-29 04:06:45', '2018-11-29 04:06:45', 'test', 'test', '', 'trash', 'closed', 'open', '', 'test__trashed', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 0, 'http://localhost/student/2018/11/29/test/', 0, 'post', '', 0),
(231, 1, '2018-11-29 04:11:45', '2018-11-29 04:11:45', 'test', 'test', '', 'trash', 'closed', 'open', '', 'test-2__trashed', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 0, 'http://localhost/student/2018/11/29/test-2/', 0, 'post', '', 0),
(232, 1, '2018-11-29 04:13:10', '2018-11-29 04:13:10', 'test', 'test', '', 'trash', 'closed', 'open', '', 'test-3__trashed', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 0, 'http://localhost/student/2018/11/29/test-3/', 0, 'post', '', 0),
(233, 1, '2018-11-29 04:14:45', '2018-11-29 04:14:45', 'test', 'test', '', 'trash', 'closed', 'open', '', 'test-4__trashed', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 0, 'http://localhost/student/2018/11/29/test-4/', 0, 'post', '', 0),
(234, 1, '2018-11-29 04:18:04', '2018-11-29 04:18:04', 'test', 'test', '', 'trash', 'closed', 'open', '', 'test-5__trashed', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 0, 'http://localhost/student/2018/11/29/test-5/', 0, 'post', '', 0),
(235, 1, '2018-11-29 04:20:04', '2018-11-29 04:20:04', 'test', 'test', '', 'inherit', 'closed', 'closed', '', '234-revision-v1', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 234, 'http://localhost/student/2018/11/29/234-revision-v1/', 0, 'revision', '', 0),
(236, 1, '2018-11-29 04:20:04', '2018-11-29 04:20:04', 'test', 'test', '', 'inherit', 'closed', 'closed', '', '233-revision-v1', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 233, 'http://localhost/student/2018/11/29/233-revision-v1/', 0, 'revision', '', 0),
(237, 1, '2018-11-29 04:20:04', '2018-11-29 04:20:04', 'test', 'test', '', 'inherit', 'closed', 'closed', '', '232-revision-v1', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 232, 'http://localhost/student/2018/11/29/232-revision-v1/', 0, 'revision', '', 0),
(238, 1, '2018-11-29 04:20:04', '2018-11-29 04:20:04', 'test', 'test', '', 'inherit', 'closed', 'closed', '', '231-revision-v1', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 231, 'http://localhost/student/2018/11/29/231-revision-v1/', 0, 'revision', '', 0),
(239, 1, '2018-11-29 04:20:04', '2018-11-29 04:20:04', 'test', 'test', '', 'inherit', 'closed', 'closed', '', '230-revision-v1', '', '', '2018-11-29 04:20:04', '2018-11-29 04:20:04', '', 230, 'http://localhost/student/2018/11/29/230-revision-v1/', 0, 'revision', '', 0),
(240, 3, '2018-11-29 14:25:31', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2018-11-29 14:25:31', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=240', 0, 'post', '', 0),
(241, 3, '2018-11-29 14:26:12', '2018-11-29 14:26:12', 'Blablabla', 'Miraz', '', 'publish', 'closed', 'open', '', 'miraz', '', '', '2018-11-29 14:26:12', '2018-11-29 14:26:12', '', 0, 'http://localhost/student/2018/11/29/miraz/', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 0, 0),
(1, 1, 0),
(19, 1, 0),
(21, 2, 0),
(21, 3, 0),
(23, 2, 0),
(25, 4, 0),
(25, 5, 0),
(27, 4, 0),
(27, 6, 0),
(29, 2, 0),
(29, 7, 0),
(31, 2, 0),
(33, 8, 0),
(33, 9, 0),
(35, 2, 0),
(37, 3, 0),
(37, 9, 0),
(39, 2, 0),
(39, 3, 0),
(41, 2, 0),
(43, 9, 0),
(43, 10, 0),
(45, 11, 0),
(47, 5, 0),
(47, 12, 0),
(47, 13, 0),
(47, 14, 0),
(49, 5, 0),
(49, 12, 0),
(49, 13, 0),
(49, 14, 0),
(51, 15, 0),
(51, 16, 0),
(51, 17, 0),
(51, 18, 0),
(53, 4, 0),
(53, 19, 0),
(55, 1, 0),
(55, 2, 0),
(57, 1, 0),
(57, 2, 0),
(59, 20, 0),
(61, 4, 0),
(61, 11, 0),
(63, 2, 0),
(65, 20, 0),
(65, 21, 0),
(67, 1, 0),
(67, 22, 0),
(69, 9, 0),
(69, 23, 0),
(71, 20, 0),
(73, 1, 0),
(73, 4, 0),
(73, 21, 0),
(75, 11, 0),
(77, 24, 0),
(77, 25, 0),
(79, 20, 0),
(79, 21, 0),
(79, 26, 0),
(81, 3, 0),
(81, 9, 0),
(81, 21, 0),
(81, 27, 0),
(83, 4, 0),
(83, 15, 0),
(85, 4, 0),
(87, 2, 0),
(87, 28, 0),
(89, 15, 0),
(89, 21, 0),
(89, 29, 0),
(89, 30, 0),
(91, 3, 0),
(91, 9, 0),
(91, 21, 0),
(93, 5, 0),
(93, 13, 0),
(93, 14, 0),
(95, 1, 0),
(95, 12, 0),
(97, 11, 0),
(101, 15, 0),
(101, 31, 0),
(103, 9, 0),
(103, 32, 0),
(105, 1, 0),
(105, 12, 0),
(159, 9, 0),
(159, 27, 0),
(159, 33, 0),
(161, 4, 0),
(161, 33, 0),
(163, 4, 0),
(165, 4, 0),
(169, 24, 0),
(169, 34, 0),
(171, 24, 0) ;
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(171, 35, 0),
(173, 24, 0),
(173, 36, 0),
(175, 24, 0),
(175, 37, 0),
(177, 11, 0),
(179, 4, 0),
(179, 38, 0),
(179, 39, 0),
(181, 15, 0),
(181, 40, 0),
(204, 4, 0),
(204, 28, 0),
(205, 1, 0),
(230, 1, 0),
(231, 1, 0),
(232, 1, 0),
(233, 1, 0),
(234, 1, 0),
(241, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------

